package com.example.demomongo4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMongo4Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoMongo4Application.class, args);
	}

}
