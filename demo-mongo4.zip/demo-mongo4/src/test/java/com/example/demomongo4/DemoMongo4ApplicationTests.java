package com.example.demomongo4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMongo4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
