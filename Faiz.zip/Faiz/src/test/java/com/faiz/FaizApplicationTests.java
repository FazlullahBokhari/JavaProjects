package com.faiz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FaizApplicationTests {

	@Test
	void contextLoads() {
	}

}
