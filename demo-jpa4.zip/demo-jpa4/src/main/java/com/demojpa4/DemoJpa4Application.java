package com.demojpa4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoJpa4Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoJpa4Application.class, args);
	}

}
