package com.example.demosecurity4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSecurity4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
