package com.example.jpabeans4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoJpaBeans4Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoJpaBeans4Application.class, args);
	}

}
